﻿using Prog6221;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part2
{
    public class Recipe
    {
        //Instances for the Recipe class
        public string RecipeName { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public double TotalCalories { get; set; }

        //Constructor for the Ingredients class
        public Recipe()
        {
            Ingredients = new List<Ingredient>();
        }
    }
}

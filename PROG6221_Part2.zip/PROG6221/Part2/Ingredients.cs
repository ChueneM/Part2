﻿using Part2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Prog6221
{
    //declaring the delegate that will display the notification
    public delegate void RecipeCaloriesNotification();
    public class Ingredients
    {
        //instance variables declared
        public int ingNum { get; set; }
        public string ingName { get; set; }
        public double ingQty { get; set; }
        public string ingMeasure { get; set; }
        public int numSteps { get; set; }
        public string description { get; set; }
        public double scale { get; set; }
        public string RecipeName { get; set; }
        public double calories { get; set; }
        public double totalCalories { get; set; }
        public string foodGroup { get; set; }
        public List<Recipe> Recipes { get; set; }
        
        //assigning the delegate 
        public RecipeCaloriesNotification CaloriesNotification { get; set; }


        //Constructor for the Generic collection
        public Ingredients()
        {
            //generic collection from the Recipe class
            Recipes = new List<Recipe>();
        }
        //populated constructor
        public Ingredients(int ingNum, string ingName, double ingQty, string ingMeasure)
        {
            this.ingNum=ingNum;
            this.ingName=ingName;
            this.ingQty=ingQty;
            this.ingMeasure=ingMeasure;
        }
        //populated constructor for steps and description
        public Ingredients(int steps, string description)
        {
            this.description=description;
            numSteps=steps;

        }

        //populated constructor
        public Ingredients(string ingName, double ingQty, string ingMeasure)
        {
            this.ingName=ingName;
            this.ingQty=ingQty;
            this.ingMeasure=ingMeasure;
        }

        //New constructor that has the calories and foodgroup added
        public Ingredients(string ingName, double ingQty, string ingMeasure, double calories, string foodGroup)
        {
            this.ingName = ingName;
            this.ingQty = ingQty;
            this.ingMeasure = ingMeasure;
            this.calories = calories;
            this.foodGroup = foodGroup;
        }

        //Method that prompts and displays to the user
        public void FullRecipe()
        {
            Recipe recipe = new Recipe();
            //prompting the user for recipe and number of ingredients
            Console.WriteLine("\nEnter the name of the recipe: ");
            recipe.RecipeName = Console.ReadLine();

            Console.WriteLine("\nPlease enter the number of ingredients: ");
            ingNum = Convert.ToInt32(Console.ReadLine());
            

            for (int i = 0; i < ingNum; i++)
            {

                //prompting the user for input 
                Console.WriteLine("Please enter the name of ingredient " + (i + 1) + ": ");
                ingName = Console.ReadLine();

                Console.WriteLine("Enter Quantity of the " + ingName + ": ", i+1);
                ingQty = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter unit of measurement" + (i+1) + ": ");
                ingMeasure = Console.ReadLine();

                //prompting user for the calories and foodGroup
                Console.WriteLine("Enter the number of calories for " + ingName + ": ");
                calories = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Enter the food group for " + ingName + ": ");
                foodGroup = Console.ReadLine();

                Console.WriteLine("*********************************************************");

                Ingredient ingredient = new Ingredient(ingName, ingQty, ingMeasure, calories, foodGroup);
                recipe.Ingredients.Add(ingredient);
                
                //Calculate total number of calories
                recipe.TotalCalories += calories;
            }

            //Asking the user for the number of steps
            Console.WriteLine($"\nPLEASE ENTER THE NUMBER OF STEPS: ");
            numSteps = Convert.ToInt32(Console.ReadLine());

            //creating an object for the steps List
            List<Ingredients> steps = new List<Ingredients>();


            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"Enter the description for step {i+1}: ");
                description = Console.ReadLine();

                Ingredients steps1 = new Ingredients(numSteps, description);
                steps.Add(steps1);
            }
            Recipes.Add(recipe);

            //check if the user total calories is greater than 300

            if (recipe.TotalCalories > 300)
            {
                CaloriesNotification?.Invoke();
                Console.WriteLine("WARNING: The total calories of the recipe exceed 300!");
            }

        }

        //method that will display the Recipes and also in alphabetical order
        public void DisplayRecipes()
        {
            Console.WriteLine("All Recipes:");

            if (Recipes.Count == 0)
            {
                Console.WriteLine("No recipes found.");
                return;
            }

            int index = 1;
            foreach (Recipe recipe in Recipes)
            {
                Console.WriteLine($"{index}. {recipe.RecipeName}");
                index++;
            }

            //Allows unlimited recipes
            Console.WriteLine("Enter the number of the recipe to display:");
            string input = Console.ReadLine();

            if (int.TryParse(input, out int recipeIndex) && recipeIndex > 0 && recipeIndex <= Recipes.Count)
            {
                Recipe selectedRecipe = Recipes[recipeIndex - 1];
                Console.WriteLine($"\nRecipe: {selectedRecipe.RecipeName}\n");

                int ingredientIndex = 1;
                foreach (Ingredient ingredient in selectedRecipe.Ingredients)
                {
                    Console.WriteLine($"Ingredient {ingredientIndex}: {ingredient.Name}");
                    Console.WriteLine($"Quantity: {ingredient.Quantity} {ingredient.Unit}");
                    Console.WriteLine($"Calories: {ingredient.Calories}");
                    Console.WriteLine($"Food Group: {ingredient.FoodGroup}\n");
                    ingredientIndex++;
                }

                Console.WriteLine($"Total Calories: {selectedRecipe.TotalCalories}");
            }
            else
            {
                Console.WriteLine("Invalid recipe number.");
            }
        }



        //Method that scales the quantity
        public void Scale()
        {
            Console.WriteLine("\nEnter the scaling factor (0.5, 2, or 3): ");
            double scale = Convert.ToDouble(Console.ReadLine());

            if (scale == 0.5 || scale == 2 || scale == 3)
            {
                foreach (Recipe recipe in Recipes)
                {
                    Console.WriteLine("\nRecipe: " + recipe.RecipeName);

                    foreach (Ingredient ingredient in recipe.Ingredients)
                    {
                        ingredient.Quantity *= scale;
                        Console.WriteLine($"Scaled quantity: {ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
                    }
                }
            }
            else
            {
                Console.WriteLine("Please enter a valid scaling factor (0.5, 2, or 3).");
            }
        }



        //method to reset the quantity
        public void ResetQty()
        {
            foreach (Recipe recipe in Recipes)
            {
                Console.WriteLine("\nRecipe: " + recipe.RecipeName);

                foreach (Ingredient ingredient in recipe.Ingredients)
                {
                    ingredient.ResetQuantity();
                    Console.WriteLine($"Reset quantity: {ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
                }
            }
        }



        //method that calculates the reset quantity
        public void ResetQuantity()
        {
            ingQty = ingQty/ingQty;
        }

        //Class to clear all the recipes and scales
        public void ClearIngredients()
        {
            Console.Clear();
            Console.WriteLine("RECIPE HAS BEEN CLEARED!!!");
        }

    }
}

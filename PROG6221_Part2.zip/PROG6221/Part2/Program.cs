﻿using Part2;
using System.Runtime.CompilerServices;

namespace Prog6221
{
    internal class Program
    {
        public static int ingNum;

        public static string ingName;
        public static int ingQty;
        public static string ingMeasure;
        public static int numSteps;
        public static string description;
        public static double scale;
        static Ingredients obj = new Ingredients();
        static void Main(string[] args)
        {


            // Assigning the notification method to the delegate
            void NotifyExceededCalories()
            {
                Console.WriteLine("WARNING: The total calories of the recipe exceed 300!");
            }

            
            while (true)
            {
                Console.WriteLine("\nPLEASE SELECT AN OPTION BELOW:\n1. Please enter a new recipe\n2. Scale a recipe\n3. Reset quantities" +
                                  "\n4. Clear all recipes\n5. Display all recipes\n6. Exit the program\n");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        obj.FullRecipe();
                        break;

                    case "2":
                        obj.Scale();
                        break;

                    case "3":
                        obj.ResetQty();
                        break;

                    case "4":
                        obj.ClearIngredients();
                        break;

                    case "5":
                        obj.DisplayRecipes();
                        break;

                    case "6":
                        Environment.Exit(0);
                        break;
                }
            }


            //skips a line after pressing enter
            Console.ReadLine();
        }
    }
}
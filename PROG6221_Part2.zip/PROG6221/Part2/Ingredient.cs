﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part2
{
    public class Ingredient
    {
        //Instances 
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }

        //Ingredient class constructor
        public Ingredient(string name, double quantity, string unit, double calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;
        }

        //Reset method
        public void ResetQuantity()
        {
            Quantity = DefaultValue(); 
        }

        private double DefaultValue()
        {
            // Return the default value for quantity
            return 0.0; 
        }
    }
}
